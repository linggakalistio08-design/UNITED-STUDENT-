import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const UnitedStudentApp());

const String appKey = 'UNITED-SEA-7K9P-2026';

class UnitedStudentApp extends StatelessWidget {
  const UnitedStudentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UNITED STUDENT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D16),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE6B84A),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const KeyPage(),
    );
  }
}

class KeyPage extends StatefulWidget {
  const KeyPage({super.key});
  @override
  State<KeyPage> createState() => _KeyPageState();
}

class _KeyPageState extends State<KeyPage> {
  final controller = TextEditingController();
  String? error;

  void enter() {
    if (controller.text.trim() == appKey) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const PanelPage()),
      );
    } else {
      setState(() => error = 'KEY SALAH. Periksa kembali key akses.');
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF101D32), Color(0xFF090D16), Color(0xFF241A12)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.sailing_rounded, size: 76, color: Color(0xFFE6B84A)),
                const SizedBox(height: 16),
                const Text('UNITED STUDENT',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: 2)),
                const SizedBox(height: 6),
                const Text('PIRATE ANIME • SAFE TEST PANEL',
                  style: TextStyle(color: Color(0xFFE6B84A), letterSpacing: 1.4, fontSize: 11)),
                const SizedBox(height: 30),
                TextField(
                  controller: controller,
                  obscureText: true,
                  onSubmitted: (_) => enter(),
                  decoration: InputDecoration(
                    labelText: 'Masukkan access key',
                    prefixIcon: const Icon(Icons.key_rounded),
                    errorText: error,
                    filled: true,
                    fillColor: const Color(0xFF172235),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton(
                    onPressed: enter,
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFE6B84A),
                      foregroundColor: const Color(0xFF17130A),
                    ),
                    child: const Text('MASUK PANEL', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
                const SizedBox(height: 18),
                const Text('Akses lokal • Tidak perlu akun WhatsApp',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ToolItem {
  final String title;
  final String description;
  final IconData icon;
  final String detail;
  const ToolItem(this.title, this.description, this.icon, this.detail);
}

const toolsList = <ToolItem>[
  ToolItem('Delay WhatsApp', 'Simulasi jeda pesan secara lokal', Icons.timer,
    'Timer ini hanya berjalan di panel. Tidak menunda, mengirim, atau mengubah chat WhatsApp.'),
  ToolItem('Force Close WhatsApp', 'Demo pemeriksaan stabilitas', Icons.phone_android,
    'Menjalankan demo pencatatan saja. Tidak menghentikan WhatsApp atau aplikasi lain.'),
  ToolItem('Stuck Logo', 'Simulasi layar loading', Icons.hourglass_top,
    'Menampilkan simulasi loading di dalam panel ini. Tidak membuat WhatsApp macet.'),
  ToolItem('Banned WhatsApp', 'Pemeriksaan risiko akun', Icons.shield,
    'Tidak dapat membanned akun. Gunakan aplikasi resmi, hindari spam, dan patuhi ketentuan WhatsApp.'),
  ToolItem('Spam Protection', 'Checklist pencegahan spam', Icons.mark_email_unread,
    'Periksa kebiasaan pengiriman pesan dan hindari pesan massal yang tidak diminta.'),
  ToolItem('Message Load Test', 'Uji beban teks contoh', Icons.text_fields,
    'Menghitung karakter teks contoh secara lokal tanpa mengirimkannya ke siapa pun.'),
  ToolItem('Connection Check', 'Pemeriksaan status jaringan dasar', Icons.wifi,
    'Demo pencatatan koneksi. Tidak mengakses server atau akun WhatsApp.'),
  ToolItem('Notification Preview', 'Pratinjau notifikasi contoh', Icons.notifications,
    'Menampilkan contoh notifikasi di panel; tidak membaca notifikasi pribadi.'),
  ToolItem('Cache & Storage Guide', 'Panduan pengelolaan penyimpanan', Icons.storage,
    'Buka Pengaturan Android untuk melihat penyimpanan WhatsApp. Jangan hapus data aplikasi tanpa cadangan.'),
  ToolItem('Permission Checklist', 'Checklist izin aplikasi', Icons.verified_user,
    'Tinjau izin aplikasi melalui Pengaturan Android. Berikan hanya izin yang diperlukan.'),
  ToolItem('Account Safety', 'Tips keamanan akun', Icons.lock,
    'Aktifkan verifikasi dua langkah dan jangan bagikan kode verifikasi atau PIN.'),
  ToolItem('Backup Reminder', 'Pengingat pencadangan', Icons.backup,
    'Periksa pengaturan cadangan WhatsApp secara berkala agar chat penting tidak hilang.'),
  ToolItem('Session Safety', 'Tips perangkat tertaut', Icons.devices,
    'Periksa menu Perangkat Tertaut dan keluarkan perangkat yang tidak dikenal.'),
  ToolItem('Log Simulator', 'Catatan aktivitas demo', Icons.receipt_long,
    'Catatan hanya tersimpan selama panel dibuka dan tidak dikirim ke server.'),
  ToolItem('App Info', 'Informasi panel', Icons.info_outline,
    'UNITED STUDENT adalah simulator offline untuk pengujian aman pada perangkat sendiri.'),
];

class PanelPage extends StatefulWidget {
  const PanelPage({super.key});
  @override
  State<PanelPage> createState() => _PanelPageState();
}

class _PanelPageState extends State<PanelPage> {
  final logs = <String>[];
  final delayController = TextEditingController(text: '5');
  Timer? timer;
  int remaining = 0;
  bool running = false;

  void log(String value) {
    setState(() => logs.insert(0, '${TimeOfDay.now().format(context)} • $value'));
  }

  void startDelay() {
    final n = int.tryParse(delayController.text.trim());
    if (n == null || n < 1 || n > 300) {
      log('Delay simulator: masukkan angka 1–300 detik.');
      return;
    }
    timer?.cancel();
    setState(() { remaining = n; running = true; });
    log('Simulasi delay dimulai ($n detik), hanya lokal.');
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => remaining--);
      if (remaining <= 0) {
        t.cancel();
        setState(() => running = false);
        log('Simulasi delay selesai.');
      }
    });
  }

  void openTool(ToolItem item) {
    log('${item.title}: dibuka.');
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ToolDetailPage(item: item, onLog: log),
    ));
  }

  @override
  void dispose() {
    timer?.cancel();
    delayController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('UNITED STUDENT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
        backgroundColor: const Color(0xFF121B2A),
        actions: [
          IconButton(
            tooltip: 'Log',
            onPressed: () => showModalBottomSheet(
              context: context,
              backgroundColor: const Color(0xFF121B2A),
              builder: (_) => SafeArea(child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('LOG PANEL', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  const SizedBox(height: 10),
                  if (logs.isEmpty) const Text('Belum ada aktivitas.')
                  else ...logs.take(10).map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 7),
                    child: Text(e, style: const TextStyle(fontSize: 12)),
                  )),
                  Align(alignment: Alignment.centerRight,
                    child: TextButton(onPressed: () { setState(logs.clear); Navigator.pop(context); }, child: const Text('HAPUS LOG'))),
                ]),
              )),
            ),
            icon: const Icon(Icons.receipt_long),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(
                colors: [Color(0xFF28476A), Color(0xFF172235), Color(0xFF4A2D18)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              border: Border.all(color: const Color(0xFFE6B84A).withOpacity(.55)),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.sailing, color: Color(0xFFE6B84A), size: 34),
              SizedBox(height: 12),
              Text('WELCOME TO THE CREW',
                style: TextStyle(color: Color(0xFFE6B84A), fontSize: 11, letterSpacing: 2)),
              SizedBox(height: 4),
              Text('UNITED STUDENT', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              Text('15 SAFE TOOLS • OFFLINE SIMULATOR', style: TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
          ),
          const SizedBox(height: 16),
          const Text('QUICK TOOL • DELAY SIMULATOR',
            style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFFE6B84A))),
          const SizedBox(height: 8),
          Card(
            color: const Color(0xFF141E2D),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(children: [
                TextField(
                  controller: delayController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Durasi simulasi (1–300 detik)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                if (running) Text('Sisa waktu: $remaining detik', style: const TextStyle(fontWeight: FontWeight.bold)),
                Row(children: [
                  Expanded(child: FilledButton(
                    onPressed: running ? null : startDelay,
                    child: const Text('MULAI'),
                  )),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: running ? () {
                      timer?.cancel();
                      setState(() { running = false; remaining = 0; });
                      log('Simulasi delay dihentikan.');
                    } : null,
                    child: const Text('STOP'),
                  ),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          const Text('ALL TOOLS', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFE6B84A))),
          const SizedBox(height: 8),
          ...toolsList.skip(1).map((item) => Card(
            color: const Color(0xFF141E2D),
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: const Color(0xFF263A53),
                child: Icon(item.icon, color: const Color(0xFFE6B84A)),
              ),
              title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              subtitle: Text(item.description, style: const TextStyle(fontSize: 11, color: Colors.white60)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => openTool(item),
            ),
          )),
          const SizedBox(height: 10),
          const Text(
            'SAFETY: Semua fitur hanya simulasi/panduan lokal. Panel tidak terhubung ke WhatsApp, tidak mengirim pesan, tidak membuat aplikasi crash, dan tidak membanned akun.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 10),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class ToolDetailPage extends StatelessWidget {
  final ToolItem item;
  final void Function(String) onLog;
  const ToolDetailPage({super.key, required this.item, required this.onLog});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(item.title)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(item.icon, size: 54, color: const Color(0xFFE6B84A)),
          const SizedBox(height: 18),
          Text(item.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text(item.detail, style: const TextStyle(fontSize: 15, height: 1.5, color: Colors.white70)),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                onLog('${item.title}: demo dijalankan.');
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Demo aman selesai. Tidak ada tindakan pada WhatsApp.')),
                );
              },
              child: const Text('JALANKAN DEMO AMAN'),
            ),
          ),
        ]),
      ),
    );
  }
}
