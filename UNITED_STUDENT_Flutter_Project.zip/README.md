# UNITED STUDENT — Flutter project

Tema: anime bajak laut original (warna laut, emas, kapal), tanpa aset karakter berhak cipta.

## Access key
`UNITED-SEA-7K9P-2026`

Key ini ditanam di aplikasi sebagai gerbang lokal sederhana. Ini bukan sistem keamanan kuat; siapa pun yang bisa membaca source dapat melihat key.

## Fitur
- Delay WhatsApp: timer simulasi lokal.
- Force Close WhatsApp: demo/pencatatan stabilitas, tidak menutup aplikasi.
- Stuck Logo: informasi/simulasi loading di panel, tidak membuat WhatsApp macet.
- Banned WhatsApp: pemeriksaan risiko dan panduan keamanan, bukan alat ban.
- Spam Protection, Message Load Test, Connection Check, Notification Preview,
  Cache & Storage Guide, Permission Checklist, Account Safety, Backup Reminder,
  Session Safety, Log Simulator, App Info.

Semua fitur bekerja lokal dan tidak mengendalikan WhatsApp, tidak mengirim pesan,
tidak menyerang perangkat lain, dan tidak membanned akun.

## Build APK
Lingkungan pembuatan file ini tidak memiliki Flutter SDK / Android SDK, jadi APK biner belum dapat dikompilasi di sini.
Di komputer/lingkungan yang memiliki Flutter:
1. Ekstrak ZIP.
2. Jalankan `flutter create .` di folder proyek untuk menghasilkan folder platform Android.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter build apk --release`.
5. APK berada di `build/app/outputs/flutter-apk/app-release.apk`.
